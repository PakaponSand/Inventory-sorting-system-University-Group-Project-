from django.urls import path
from django.contrib.auth import views as auth_views
from . import views 
from .views import save_reservation
from .views import bookings_view
from .views import cancel_booking
from .views import dismiss_booking



urlpatterns = [
    path("", views.home, name="home"),
    path("inventory/", views.inventory, name="inventory"),
    path("contact/", views.contact, name="contact"),
    path("account/", views.account, name="account"),
    path("terms/",views.terms, name="terms"),
    path("reservations/",views.reservations, name="reservations"),
    path("bookings/",views.bookings, name="bookings"),
    path("overdue/",views.overdue, name="overdue"),
    path('save_reservation/', save_reservation, name='save_reservation'),
    path('bookings/<int:reservation_id>/', bookings_view, name='bookings'),
    path('bookings/<int:reservation_id>/', bookings_view, name='bookings_detail'),
    path('book_reservation/<int:reservation_id>/', views.book_reservation, name='book_reservation'),
    path('my_bookings/', views.my_bookings, name='my_bookings'),
    path('change-booking-status/<int:booking_id>/', views.change_booking_status, name='change_booking_status'),
    path('cancel-booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
    path('dismiss-booking/<int:booking_id>/', dismiss_booking, name='dismiss_booking'),
    path('cancel-reservation/<int:reservation_id>/', views.cancel_reservation, name='cancel_reservation'),
    
]


