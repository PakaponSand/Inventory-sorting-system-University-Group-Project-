from django.contrib import admin
from .models import InventoryItem
from .models import Reservation
from .models import Bookings
from import_export.admin import ImportExportActionModelAdmin


# Register your models here.
admin.site.register(InventoryItem, ImportExportActionModelAdmin)
admin.site.register(Reservation, ImportExportActionModelAdmin)
admin.site.register(Bookings, ImportExportActionModelAdmin)