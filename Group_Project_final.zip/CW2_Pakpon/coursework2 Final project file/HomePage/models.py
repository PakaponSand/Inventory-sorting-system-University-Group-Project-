from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class InventoryItem(models.Model):

    DEVICE_TYPES = (
        ('Laptop', 'Laptop'),
        ('Mobile Device', 'Mobile Device'),
        ('Non-Portable PC', 'Non-Portable PC'),
        ('Standalone Headset', 'Standalone Headset'),
        
    )

    Storage = (
        ('2GB', '2GB'),
        ('4GB', '4GB'),
        ('8GB', '8GB'),
        ('16GB', '16GB'),
        ('32GB', '32GB'),
        ('64GB', '64GB')
    )
        
    

    Device_Name = models.CharField(max_length=100)
    Device_Type = models.CharField(max_length=100, choices=DEVICE_TYPES)
    Device_Serial = models.CharField(max_length=15)
    CPU= models.CharField(max_length=100)
    GPU= models.CharField(max_length=100)
    RAM= models.CharField(max_length=100, choices=Storage)
    stock = models.PositiveIntegerField(default=1)


class Reservation(models.Model):
    device_name = models.CharField(max_length=100)
    device_type = models.CharField(max_length=100)
    device_serial = models.CharField(max_length=100)
    cpu = models.CharField(max_length=100)
    gpu = models.CharField(max_length=100)
    ram = models.CharField(max_length=100)

class Bookings(models.Model):
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    )
    
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    bookdevice_name = models.CharField(max_length=100)
    bookdevice_type = models.CharField(max_length=100)
    bookdevice_serial = models.CharField(max_length=100)
    bookcpu = models.CharField(max_length=100)
    bookgpu = models.CharField(max_length=100)
    bookram = models.CharField(max_length=100)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    approval_date = models.DateTimeField(blank=True, null=True)
    return_date = models.DateTimeField(blank=True, null=True)