from django.shortcuts import render, HttpResponse
from .models import InventoryItem
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from . import views
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
from django.shortcuts import render, redirect 
from django.contrib.auth.decorators import login_required
from.models import InventoryItem
from django.contrib.auth.forms import PasswordChangeForm, UserChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import CustomUserChangeForm
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.core.mail import send_mail
import json
from django.http import JsonResponse
from .models import Reservation
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.shortcuts import get_object_or_404, render
from .models import Bookings
from django.shortcuts import render, redirect
from .models import Reservation, Bookings
from django.shortcuts import render
from .models import Bookings
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import user_passes_test
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import render
from .models import Bookings
from django.shortcuts import render
from django.utils import timezone
from django.shortcuts import render
from .models import Bookings
from datetime import datetime
from django.utils import timezone









def home(request):
    return render(request, "home.html")

def terms(request):
    return render(request, "terms.html")

@login_required(login_url= 'login')
def inventory(request):
    
    inventory_items = InventoryItem.objects.all()
    return render(request, "inventory.html", {"inventory": inventory_items})


def contact(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']

        #send email bit
        send_mail (
            name + ", " + subject, #subject
            message, #message
            email, #from
            ['inventorytechhub@gmail.com'], #to email
        )

        return render(request, "contact.html", {"name": name})

    else:
        return render(request, "contact.html", {})


@login_required(login_url= 'login')
def reservations(request):
    # Retrieve all reservations from the database
    reservations = Reservation.objects.all()
    
    # Pass the reservations to the template context
    context = {
        'reservations': reservations
    }
    
    # Render the reservations.html template with the reservations data
    return render(request, 'reservations.html', context)
@login_required(login_url= 'login')
def bookings(request):
    # Retrieve all bookings from the database
    bookings = Bookings.objects.all()
    
    # Pass the bookings to the template context
    context = {
        'bookings': bookings
    }
    
    # Render the bookings.html template with the bookings data
    return render(request, "bookings.html", context)

@login_required(login_url='login')
def overdue(request):
    # Retrieve only approved bookings from the database
    approved_bookings = Bookings.objects.filter(status='Approved')
    
    # Calculate the threshold date for "due soon" items (e.g., within the next 3 days)
    threshold_date = timezone.now() + timezone.timedelta(days=3)
    
    # Check if any booking's return date is within the threshold
    any_booking_due_soon = approved_bookings.filter(return_date__lte=threshold_date).exists()
    
    # Pass the context variables to the template
    context = {
        'approved_bookings': approved_bookings,
        'any_booking_due_soon': any_booking_due_soon
    }
    
    # Render the overdue.html template with the context
    return render(request, "overdue.html", context)

@login_required(login_url= 'login')
def account(request):
    return render(request, "account.html")

class CustomLoginView(LoginView):
    template_name = 'login.html'
    success_url = reverse_lazy('home')  # Replace 'home' with the name of your home page URL

@login_required(login_url='login')
def account(request):
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=request.user)
        password_form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid() and password_form.is_valid():
            form.save()
            password_form.save()
            update_session_auth_hash(request, request.user)  # Important to keep the user logged in
            messages.success(request, 'Your account information has been updated successfully.')
            return redirect('account')
    else:
        form = CustomUserChangeForm(instance=request.user)
        password_form = PasswordChangeForm(request.user)

    return render(request, "account.html", {'form': form, 'password_form': password_form})


@csrf_exempt
def save_reservation(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        print('Received Reservation Data:', data)  # Check if data is received
        
        # Check if the reservation already exists in the reservations database
        existing_reservation = Reservation.objects.filter(
            device_name=data['device_name'],
            device_type=data['device_type'],
            device_serial=data['device_serial'],
            cpu=data['cpu'],
            gpu=data['gpu'],
            ram=data['ram']
        ).exists()
        
        if existing_reservation:
            # If the reservation already exists, return an error response
            return JsonResponse({'error': 'Reservation already exists'}, status=400)
        else:
            # If the reservation does not exist, create a new reservation
            try:
                reservation = Reservation.objects.create(
                    device_name=data['device_name'],
                    device_type=data['device_type'],
                    device_serial=data['device_serial'],
                    cpu=data['cpu'],
                    gpu=data['gpu'],
                    ram=data['ram']
                )
                print('Reservation saved successfully')  # Check if reservation is saved successfully
                return JsonResponse({'message': 'Reservation saved successfully'})
            except Exception as e:
                print('Error saving reservation:', e)  # Print any errors that occur
                return JsonResponse({'error': 'Error saving reservation'}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)


def bookings_view(request, reservation_id):
    try:
        # Retrieve the reservation object based on the provided ID
        reservation = Reservation.objects.get(id=reservation_id)
    except Reservation.DoesNotExist:
        # Handle the case where the reservation does not exist
        # You can return an error page or redirect the user to another URL
        return render(request, 'error.html', {'error_message': 'Reservation not found'})

    # Pass the reservation object to the template context
    return render(request, 'bookings.html', {'reservation': reservation})


@login_required(login_url='login')
def book_reservation(request, reservation_id):
    if request.method == 'POST':
        try:
            # Retrieve the reservation object based on the provided ID
            reservation = Reservation.objects.get(id=reservation_id)
            
            # Check if a booking already exists for this reservation and user
            if Bookings.objects.filter(reservation=reservation, user=request.user).exists():
                # If a booking exists, show an error message
                messages.error(request, 'You have already booked this device.')
                return redirect('reservations')  # Redirect to reservations page or another appropriate URL
            else:
                # Create a new booking object using reservation details
                booking = Bookings.objects.create(
                    reservation=reservation,
                    user=request.user,  # Assuming the current user is making the booking
                    bookdevice_name=reservation.device_name,
                    bookdevice_type=reservation.device_type,
                    bookdevice_serial=reservation.device_serial,
                    bookcpu=reservation.cpu,
                    bookgpu=reservation.gpu,
                    bookram=reservation.ram
                )
                
                # Redirect to a success page or another appropriate URL
                return redirect('bookings')  # Replace 'bookings' with the name of your bookings page URL
        except Reservation.DoesNotExist:
            # Handle the case where the reservation does not exist
            # You can return an error page or redirect the user to another URL
            return render(request, 'error.html', {'error_message': 'Reservation not found'})
    else:
        # Handle GET requests appropriately, if needed
        pass

@login_required(login_url='login')  # Ensure only authenticated users can access this view
def my_bookings(request):
    # Retrieve bookings associated with the current user
    bookings = Bookings.objects.filter(user=request.user)
    
    # Pass the bookings to the template context
    context = {
        'bookings': bookings
    }
    
    # Render the my_bookings.html template with the bookings data
    return render(request, 'my_bookings.html', context)


@user_passes_test(lambda u: u.is_staff, login_url='bookings')
def change_booking_status(request, booking_id):
    if request.method == 'POST':
        new_status = request.POST.get('status')
        booking = get_object_or_404(Bookings, id=booking_id)
        
        # Update the booking status
        booking.status = new_status
        
        # If the status is being changed to 'Approved', assign the approval date and one week later date
        if new_status == 'Approved':
            booking.approval_date = datetime.now()  # Assign the current date as the approval date
            booking.return_date = datetime.now() + timedelta(weeks=1)  # Assign one week later date as return date
        
        booking.save()
        
        # Redirect the admin to another page after changing the status
        return redirect('bookings')

    # If the request method is not POST, render a form for the admin to select the new status
    return render(request, 'change_booking_status.html', {'booking_id': booking_id})

@csrf_exempt
def cancel_booking(request, booking_id):
    if request.method == 'POST':
        try:
            booking = Bookings.objects.get(id=booking_id)  # Corrected typo here
            booking.delete()
            return JsonResponse({'message': 'Booking canceled successfully'}, status=200)
        except Bookings.DoesNotExist:  # Corrected typo here
            return JsonResponse({'error': 'Booking does not exist'}, status=404)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)

@csrf_exempt
def dismiss_booking(request, booking_id):
    if request.method == 'POST':
        try:
            booking = Bookings.objects.get(id=booking_id)
            booking.delete()
            return JsonResponse({'message': 'Booking dismissed successfully'}, status=200)
        except Bookings.DoesNotExist:
            return JsonResponse({'error': 'Booking does not exist'}, status=404)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    
def cancel_reservation(request, reservation_id):
    if request.method == 'POST':
        try:
            reservation = Reservation.objects.get(id=reservation_id)
            reservation.delete()
            return HttpResponseRedirect(reverse('reservations'))  # Redirect back to reservations page after cancellation
        except Reservation.DoesNotExist:
            # Handle case where reservation does not exist
            return render(request, 'error.html', {'error_message': 'Reservation not found'})
    else:
        # Handle cases where method is not POST (optional)
        pass

